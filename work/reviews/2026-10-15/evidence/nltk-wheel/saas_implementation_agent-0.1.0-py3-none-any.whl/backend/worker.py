"""Celery delivery with DB-owned checkpoints and replay-safe node transactions."""
from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from typing import TypedDict

from celery import Celery, Task
from fastapi import HTTPException
from langchain_core.runnables import RunnableLambda
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from backend.access import require_project_permission
from backend.config import get_settings
from backend.models import AgentRun, Project, Tenant, TenantMembership, User, WorkflowOutbox
from backend.schemas import Role
from backend.security import Principal
from backend.state_machine import ProjectLifecycle, RunLifecycle, transition_project, transition_run
from backend.workflow import NODES, advance


class GuardedTask(Task):
    def __call__(self, *args, **kwargs):
        async def verify():
            from backend.runtime_guard import check_runtime_role
            engine = create_async_engine(get_settings().database_url, poolclass=NullPool)
            try:
                async with engine.connect() as connection:
                    await check_runtime_role(connection)
            finally:
                await engine.dispose()
        from backend.observability import setup
        setup("saas-implementation.worker")
        asyncio.run(verify())
        return super().__call__(*args, **kwargs)


celery = Celery("implementation", broker=get_settings().redis_url, task_cls=GuardedTask)
celery.conf.update(
    task_acks_late=True, task_reject_on_worker_lost=True, worker_prefetch_multiplier=1,
    task_soft_time_limit=240, task_time_limit=300,
    task_routes={"implementation.knowledge": {"queue": "indexing"},
                 "implementation.index_tenant": {"queue": "indexing"},
                 "implementation.cleanup": {"queue": "indexing"}},
    beat_schedule={"cleanup": {"task": "implementation.cleanup", "schedule": 3600.0}, "chat_context": {"task": "implementation.chat_context", "schedule": 5.0}, "outbox": {"task": "implementation.dispatch", "schedule": 2.0}, "mail": {"task": "implementation.mail", "schedule": 10.0}, "knowledge": {"task": "implementation.knowledge", "schedule": 10.0}},
)


async def actor_context(session, event):
    membership = await session.scalar(select(TenantMembership).where(TenantMembership.user_id == event.actor_id, TenantMembership.tenant_id == event.tenant_id, TenantMembership.status == "active").execution_options(populate_existing=True))
    user = await session.get(User, event.actor_id, populate_existing=True)
    tenant = await session.get(Tenant, event.tenant_id, populate_existing=True)
    if (not membership or not user or user.status != "active" or user.deleted_at is not None
            or user.account_type != "customer" or not tenant or tenant.status != "active"
            or tenant.deleted_at is not None
            or tenant.kind == "personal" and tenant.personal_owner_id != user.id):
        raise HTTPException(403, "执行人的公司授权已失效")
    if session.bind.dialect.name == "postgresql":
        session.info["rls_context"] = {"app.current_user_id": user.id, "app.current_tenant_id": event.tenant_id, "app.current_company_role": membership.company_role_code, "app.platform_roles": "", "app.is_platform_admin": "false"}
        for key, value in session.info["rls_context"].items():
            await session.execute(text("SELECT set_config(:key, :value, true)"), {"key": key, "value": value})
    return Principal(user_id=user.id, subject=user.email or user.username, email=user.email or "", username=user.username, display_name=user.display_name, tenant_id=tenant.id, tenant_name=tenant.name, account_type=user.account_type, session_context="customer", role=Role.TENANT_ADMIN if membership.company_role_code == "company_admin" else Role.TENANT_MEMBER, is_platform_admin=False, company_role_code=membership.company_role_code, platform_roles=(), session_id="worker", workspace_kind=tenant.kind)


class Cursor(TypedDict):
    next: str


def next_node(run: AgentRun) -> str:
    if run.status == "pending":
        return NODES[0]
    if run.status != "running":
        return END
    completed = run.state.get("completed_nodes", [])
    return next((node for node in NODES if node not in completed), END)


async def process_event(event_id: str, *, checkpointer=None, raise_errors: bool = False) -> None:
    from backend.observability import setup, span
    setup("saas-implementation.worker")
    engine = create_async_engine(get_settings().database_url, poolclass=NullPool)
    try:
        from backend.runtime_guard import check_runtime_role
        async with engine.connect() as connection:
            await check_runtime_role(connection)
        async with async_sessionmaker(engine)() as session:
            event = await session.get(WorkflowOutbox, event_id)
            if not event or event.processed:
                return
            parent = event.trace_context
        with span("worker.consume", parent=parent, event_id=event_id):
            await _process_event(event_id, checkpointer=checkpointer, raise_errors=raise_errors)
    finally:
        await engine.dispose()


async def _process_event(event_id: str, *, checkpointer=None, raise_errors: bool = False) -> None:
    engine = create_async_engine(get_settings().database_url, poolclass=NullPool)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with factory() as owner:
            # Held across the graph: duplicate deliveries cannot interleave.
            event = await owner.scalar(select(WorkflowOutbox).where(WorkflowOutbox.id == event_id).with_for_update(skip_locked=True))
            if not event or event.processed:
                return

            async def step(_: Cursor) -> Cursor:
                async with factory() as session:
                    principal = await actor_context(session, event)
                    run = await session.scalar(select(AgentRun).where(AgentRun.id == event.run_id).with_for_update())
                    if not run:
                        raise HTTPException(403, "项目访问权限已撤销")
                    if run.status == "pending":
                        transition_run(run, RunLifecycle.RUNNING)
                        run.state = {**run.state, "status": "running"}
                    if run.status != "running":
                        return {"next": END}
                    project = await session.get(Project, run.project_id)
                    if project is None or project.deleted_at:
                        transition_run(run, RunLifecycle.CANCELLED)
                        run.state = {**run.state, "status": "cancelled", "blocking_reason": "项目已删除"}
                    else:
                        await require_project_permission(session, project, principal, "run.start")
                        await advance(session, run, one_node=True)
                    await session.commit()
                    return {"next": next_node(run)}

            try:
                async with factory() as session:
                    await actor_context(session, event)
                    run = await session.get(AgentRun, event.run_id)
                    if not run:
                        raise HTTPException(403, "项目访问权限已撤销")
                    initial = next_node(run)
                graph = StateGraph(Cursor)
                for node in NODES:
                    graph.add_node(node, RunnableLambda(step))
                    graph.add_conditional_edges(node, lambda cursor: cursor["next"])
                graph.add_conditional_edges(START, lambda cursor: cursor["next"])
                compiled = graph.compile(checkpointer=checkpointer or InMemorySaver())
                await compiled.ainvoke({"next": initial}, {"configurable": {"thread_id": event.id}, "recursion_limit": 600}, durability="sync")
                event.processed = True
                event.last_error = ""
            except Exception as exc:
                if raise_errors:
                    raise
                event.attempts += 1
                event.last_error = type(exc).__name__  # never persist credential-bearing exception strings
                event.next_attempt_at = datetime.now(UTC) + timedelta(seconds=2 ** event.attempts)
                terminal = isinstance(exc, HTTPException) or event.attempts >= 3
                if terminal:
                    event.processed = True
                    async with factory() as session:
                        try:
                            await actor_context(session, event)
                            run = await session.scalar(select(AgentRun).where(AgentRun.id == event.run_id).with_for_update())
                            if run and run.status in {"pending", "running"}:
                                if run.status == "pending":
                                    transition_run(run, RunLifecycle.RUNNING)
                                transition_run(run, RunLifecycle.FAILED)
                                run.state = {**run.state, "status": "failed", "blocking_reason": f"执行失败：{event.last_error}；请检查依赖后创建整改 Run"}
                                project = await session.get(Project, run.project_id)
                                if project and project.lifecycle_status == "in_progress":
                                    transition_project(project, ProjectLifecycle.BLOCKED)
                                await session.commit()
                        except HTTPException:
                            # No privilege escalation when the original actor lost access.
                            # The outbox failure remains visible to platform operations.
                            pass
            await owner.commit()
    finally:
        await engine.dispose()


async def consume(event_id):
    if get_settings().database_url.startswith("postgresql"):
        from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
        url = get_settings().database_url.replace("postgresql+psycopg://", "postgresql://", 1)
        async with AsyncPostgresSaver.from_conn_string(url) as saver:
            await process_event(event_id, checkpointer=saver)
    else:
        await process_event(event_id)


@celery.task(name="implementation.run")
def execute(event_id: str):
    asyncio.run(consume(event_id))


async def publish():
    engine = create_async_engine(get_settings().database_url, poolclass=NullPool)
    factory = async_sessionmaker(engine)
    try:
        async with factory() as session:
            events = (await session.scalars(select(WorkflowOutbox).where(WorkflowOutbox.processed.is_(False), WorkflowOutbox.next_attempt_at <= datetime.now(UTC)).limit(100).with_for_update(skip_locked=True))).all()
            for event in events:
                execute.apply_async(args=[event.id], headers=event.trace_context)
                # A lost message is republished. An active consumer owns a row lock.
                event.next_attempt_at = datetime.now(UTC) + timedelta(seconds=60)
            await session.commit()
    finally:
        await engine.dispose()


@celery.task(name="implementation.dispatch")
def dispatch_outbox():
    asyncio.run(publish())


@celery.task(name="implementation.health_probe")
def health_probe(identifier: str):
    # No business data or email; an expiring canary proves real queue consumption.
    import re

    from redis import Redis
    if not re.fullmatch(r"[0-9a-f]{32}", identifier):
        raise ValueError("Invalid acceptance identifier")
    from backend.observability import span
    with span("worker.health_probe", parent=dict(health_probe.request.headers or {})):
        with Redis.from_url(get_settings().redis_url, socket_timeout=3, socket_connect_timeout=3) as client:
            client.set(f"acceptance:worker:{identifier}", "consumed", ex=60)


@celery.task(name="implementation.mail")
def deliver_mail():
    from backend.mailer import flush_mail
    asyncio.run(flush_mail())


async def setup_checkpoints():
    from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

    from backend.db_role import owner_url
    async with AsyncPostgresSaver.from_conn_string(owner_url()) as saver:
        await saver.setup()


async def index_knowledge(tenant_id=None, stage=None):
    from backend.knowledge import process_pending
    from backend.retrieval_sources import process_sources
    engine = create_async_engine(get_settings().database_url, poolclass=NullPool)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with factory() as session:
            tenants = [tenant_id] if tenant_id else list(await session.scalars(select(Tenant.id).where(Tenant.status == "active")))
        for identifier in tenants:
            # One document per transaction, independent of other origins or tenants.
            for branch in ([stage] if stage else ["sources", "knowledge"]):
                async with factory() as session:
                    session.info["rls_context"] = {"app.current_tenant_id": identifier,
                        "app.current_company_role": "company_admin"}
                    if session.bind.dialect.name == "postgresql":
                        for key, value in session.info["rls_context"].items():
                            await session.execute(text("SELECT set_config(:key, :value, true)"), {"key": key, "value": value})
                    if branch == "sources":
                        if get_settings().rag_mode == "real":
                            await process_sources(session, identifier, limit=1)
                        else:
                            await process_pending(session, identifier, limit=1)
                    elif get_settings().retrieval_indexing_enabled:
                        from backend.knowledge_index import process
                        await process(session, identifier, limit=1)
                    await session.commit()
    finally:
        await engine.dispose()


@celery.task(name="implementation.knowledge", soft_time_limit=30, time_limit=45)
def build_knowledge_indexes():
    import secrets

    from redis import Redis

    async def tenant_ids():
        engine = create_async_engine(get_settings().database_url, poolclass=NullPool)
        try:
            async with async_sessionmaker(engine)() as session:
                return list(await session.scalars(select(Tenant.id).where(Tenant.status == "active")))
        finally:
            await engine.dispose()
    # Bound queue growth even when scheduler ticks arrive during a slow PDF.
    with Redis.from_url(get_settings().redis_url, socket_timeout=3) as cache:
        if cache.llen("indexing"):
            return
        candidates = [(tenant, stage) for tenant in sorted(asyncio.run(tenant_ids()))
                      for stage in ("sources", "knowledge")]
        for _ in candidates:
            tenant, stage = candidates[(cache.incr("index-job:cursor") - 1) % len(candidates)]
            key, token = f"index-job:{tenant}:{stage}", secrets.token_hex(16)
            if cache.set(key, token, nx=True, ex=1200):
                try:
                    index_tenant.delay(tenant, stage, token)
                    break
                except Exception:
                    cache.eval("if redis.call('GET',KEYS[1])==ARGV[1] then return redis.call('DEL',KEYS[1]) end return 0", 1, key, token)
                    raise


@celery.task(name="implementation.index_tenant", soft_time_limit=870, time_limit=900)
def index_tenant(tenant_id, stage, token):
    from redis import Redis
    key = f"index-job:{tenant_id}:{stage}"
    with Redis.from_url(get_settings().redis_url, socket_timeout=3) as cache:
        if not cache.eval("if redis.call('GET',KEYS[1])==ARGV[1] then return redis.call('EXPIRE',KEYS[1],1200) end return 0", 1, key, token):
            return
        try:
            asyncio.run(index_knowledge(tenant_id, stage))
        finally:
            cache.eval("if redis.call('GET',KEYS[1])==ARGV[1] then return redis.call('DEL',KEYS[1]) end return 0", 1, key, token)


@celery.task(name="implementation.cleanup", soft_time_limit=240, time_limit=300)
def cleanup_projects():
    from backend.cleanup import drain_cleanup, purge_expired_projects

    async def clean():
        engine = create_async_engine(get_settings().database_url, poolclass=NullPool)
        factory = async_sessionmaker(engine, expire_on_commit=False)
        try:
            async with factory() as session:
                tenants = list(await session.scalars(select(Tenant.id).where(Tenant.deleted_at.is_(None))))
            for tenant in tenants:
                async with factory() as session:
                    session.info["rls_context"] = {"app.current_tenant_id": tenant, "app.current_company_role": "company_admin"}
                    if session.bind.dialect.name == "postgresql":
                        for key, value in session.info["rls_context"].items():
                            await session.execute(text("SELECT set_config(:key, :value, true)"), {"key": key, "value": value})
                    await purge_expired_projects(session, tenant)
                    await drain_cleanup(session)
        finally:
            await engine.dispose()
    asyncio.run(clean())


if __name__ == "__main__":
    asyncio.run(setup_checkpoints())


@celery.task(name="implementation.chat_context")
def build_chat_context():
    from backend.context_maintenance import maintain_pending
    asyncio.run(maintain_pending())
